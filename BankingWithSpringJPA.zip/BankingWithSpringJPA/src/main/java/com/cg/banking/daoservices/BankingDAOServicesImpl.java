package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utilities.BankingUtility;


@Component("bankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices {

	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;

	public static  Map<Integer,Customer> customers;

	@Override
	public int insertCustomer(Customer customer) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Customer customer=entityManager.find(Customer.class, customerId);
		account.setCustomer(customer);
		account.setStatus(BankingUtility.ACCOUNT_STATUS_ACTIVE);
		entityManager.persist(account);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {

		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {

		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {

		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Customer customer=entityManager.find(Customer.class, customerId);
	//	entityManager.flush();
		entityManager.close();
		return customer;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Account account=entityManager.find(Account.class, accountNo);
		entityManager.close();
		return account;
	}

	@Override
	public List<Customer> getCustomers() {

		return null;
	}

	@Override
	public List<Account> getAccounts(int customerId) {

		return null;
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {

		return null;
	}

}
