package com.cg.banking.utilities;

public class BankingUtility {
	public static int CUSTOMER_ID_COUNTER=111;
	public static long ACCOUNT_NO_COUNTER=20000001l;
	public static int TRANSACTION_ID_COUNTER=100;
	public static final String ACCOUNT_STATUS_ACTIVE="ACTIVE";
	public static final String ACCOUNT_STATUS_INACTIVE="INACTIVE";
	public static final String ACCOUNT_STATUS_BLOCKED = "BLOCKED";
}
